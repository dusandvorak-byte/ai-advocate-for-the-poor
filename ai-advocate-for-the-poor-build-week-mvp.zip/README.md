# AI Advocate for the Poor

**Turning fragmented legal archives into auditable institutional memory.**

This repository contains the first public OpenAI Build Week prototype.

## What it does

The demo analyses a new legal or administrative document and:

- extracts authority, date and case reference;
- classifies the procedural type;
- distinguishes what the document proves from what it does not prove;
- recommends the proceedings, reviews or supervisory branches to which it may belong;
- generates a human-reviewable working draft;
- identifies missing follow-up information.

## Try it locally

Open `docs/index.html` in a modern browser. Click **Načíst ukázkový dokument**, then **Analyzovat dokument**.

## Publish with GitHub Pages

Go to **Settings → Pages → Deploy from a branch**, select `main` and `/docs`, then save.

Expected public URL:

`https://dusandvorak-byte.github.io/ai-advocate-for-the-poor/`

## Use of GPT-5.6

GPT-5.6 was used for legal document analysis, fact/evidence/inference separation, routing logic, cautious output language, translation, and Build Week documentation.

## Use of Codex

The next step is to open this repository in Codex and use one principal session to extend the prototype with PDF/DOCX ingestion, an evidence graph, source citations, persistence and automated tests. After most core functionality is built there, run `/feedback` and submit the returned Session ID to Devpost.

## Human-in-the-loop limitation

This prototype does not replace a lawyer, court or public authority. Outputs are working recommendations and must be checked against primary documents.

## Social impact

The project aims to support people with disabilities in long-running document-heavy proceedings. From March 2027, Dušan Dvořák plans a roughly 2,000 km pilgrimage from Geneva to Santiago de Compostela with his wife and their dogs as a European field project for accessible AI.

## Research programme

Cannabis is The Cure / Konopí je lék — https://www.konopijelek.cz/

## License

MIT
